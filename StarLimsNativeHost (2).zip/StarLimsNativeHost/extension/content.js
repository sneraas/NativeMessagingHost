window.addEventListener("message", event => {
    if (event.source !== window) return;
    if (event.data?.source !== "STARLIMS_LOCAL") return;

    chrome.runtime.sendMessage(event.data, response => {
        window.postMessage({
            source: "STARLIMS_LOCAL_RESPONSE",
            requestId: event.data.requestId,
            response
        }, "*");
    });
});