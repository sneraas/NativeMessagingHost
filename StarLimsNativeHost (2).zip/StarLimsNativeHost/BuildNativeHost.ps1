param(
    [string]$SourceFile = ".\Program.cs",
    [string]$OutputDir = ".\publish",
    [string]$Runtime = "win-x64"
)

$ErrorActionPreference = "Stop"

if (-not (Test-Path $SourceFile)) {
    throw "Source file not found: $SourceFile"
}

$SourceFile = (Resolve-Path $SourceFile).Path
$OutputDir = [System.IO.Path]::GetFullPath($OutputDir)

$tempDir = Join-Path $env:TEMP ("NativeHostBuild_" + [guid]::NewGuid().ToString("N"))
$projectFile = Join-Path $tempDir "NativeHost.csproj"
$programFile = Join-Path $tempDir "Program.cs"

New-Item -ItemType Directory -Path $tempDir | Out-Null
New-Item -ItemType Directory -Force -Path $OutputDir | Out-Null

Copy-Item $SourceFile $programFile

$project = @"
<Project Sdk="Microsoft.NET.Sdk">
  <PropertyGroup>
    <OutputType>Exe</OutputType>
    <TargetFramework>net8.0</TargetFramework>

    <ImplicitUsings>enable</ImplicitUsings>
    <Nullable>enable</Nullable>

    <RuntimeIdentifier>$Runtime</RuntimeIdentifier>
    <SelfContained>true</SelfContained>
    <PublishSingleFile>true</PublishSingleFile>
    <IncludeNativeLibrariesForSelfExtract>true</IncludeNativeLibrariesForSelfExtract>

    <DebugType>None</DebugType>
    <DebugSymbols>false</DebugSymbols>

    <AssemblyName>StarlimsNativeHost</AssemblyName>
  </PropertyGroup>
</Project>
"@

Set-Content -Path $projectFile -Value $project -Encoding UTF8

try {
    dotnet publish $projectFile `
        -c Release `
        -o $OutputDir

    if ($LASTEXITCODE -ne 0) {
        throw "dotnet publish failed with exit code $LASTEXITCODE"
    }

    $exe = Join-Path $OutputDir "StarlimsNativeHost.exe"

    if (-not (Test-Path $exe)) {
        throw "Publish completed, but EXE was not found: $exe"
    }

    Write-Host ""
    Write-Host "Build complete:"
    Write-Host $exe
}
finally {
    if (Test-Path $tempDir) {
        Remove-Item $tempDir -Recurse -Force
    }
}